#ifndef YHJSWIDGET_H
#define YHJSWIDGET_H

#include <QObject>
#include <QWidget>
#include"abstmainwidget.h"
class yhjsWidget:public abstmainwidget
{
public:
    yhjsWidget(QWidget*parent=0);
};

#endif // YHJSWIDGET_H
